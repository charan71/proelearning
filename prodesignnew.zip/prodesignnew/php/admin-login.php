<?php

echo 'works';

print_r($_POST);

?>