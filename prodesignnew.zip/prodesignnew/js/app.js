/* Creating Module */
var app = angular.module('ProELearning', ['ngRoute', 'ngAnimate', 'ngTouch', 'ProELearning.controllers', 'ProELearning.services', 'ProELearning.directives', 'ng-clamp'])

/* Resolve Views Scroll Point Issue */
.run(['$rootScope', '$document', function($rootScope, $document) {
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        $rootScope.title = current.$$route.title;
        $document[0].body.scrollTop = $document[0].documentElement.scrollTop = 0;
    });
}])

/* Creating Route Configurations For Partial Views */
.config(['$routeProvider', '$locationProvider', 
            function ($routeProvider, $locationProvider)
            {
                $routeProvider
                    .when("/",
                          {
                    title: "Pro E-Learning | DevOps, RPA, ETL, ERP, Java, Websphere, Hadoop, More...",
                    templateUrl: "views/home.php",
                    controller: "CourseCardsController"
                })
                    .when("/search-results",
                          {
                    title: "Search Results - Pro E-Learning",
                    templateUrl: "views/search-results.html",
                    controller: "searchCoursesController"
                })
                    .when("/information-technology",
                          {
                    title: "Information Technology - Pro E-Learning",
                    templateUrl: "views/information-technology.html",
                    controller: ""
                })
                    .when("/information-technology/java",
                          {
                    title: "Java - Pro E-Learning",
                    templateUrl: "views/java.html",
                    controller: ""
                })
                    .when("/information-technology/dotnet",
                          {
                    title: "Dot Net - Pro E-Learning",
                    templateUrl: "views/dotnet.html",
                    controller: "dotnetController"
                })
                    .when("/information-technology/python",
                          {
                    title: "Python - Pro E-Learning",
                    templateUrl: "views/python.html",
                    controller: ""
                })
                    .when("/information-technology/embedded-systems",
                          {
                    title: "Embedded Systems - Pro E-Learning",
                    templateUrl: "views/embedded-systems.html",
                    controller: "embeddedSystemsCtrl"
                })
                    .when("/information-technology/unix",
                          {
                    title: "UNIX - Pro E-Learning",
                    templateUrl: "views/unix.html",
                    controller: ""
                })
                    .when("/information-technology/linux",
                          {
                    title: "Linux - Pro E-Learning",
                    templateUrl: "views/linux.html",
                    controller: ""
                })
                    .when("/information-technology/build-and-deployment-engineer",
                          {
                    title: "Build and Deployment Engineer (Information Technology) - Pro E-Learning",
                    templateUrl: "views/build-deploy-eng.html",
                    controller: ""
                })
                    .when("/information-technology/build-release-engineer",
                          {
                    title: "Build Release Engineer (Information Technology) - Pro E-Learning",
                    templateUrl: "views/build-release.html",
                    controller: ""
                })
                    .when("/information-technology/ruby",
                          {
                    title: "Ruby (Information Technology) - Pro E-Learning",
                    templateUrl: "views/ruby.html",
                    controller: ""
                })
                    .when("/information-technology/sharepoint",
                          {
                    title: "SharePoint (Information Technology) - Pro E-Learning",
                    templateUrl: "views/sharepoint.html",
                    controller: ""
                })
                    .when("/information-technology/itil-v3-foundation",
                          {
                    title: "ITIL V3 Foundation (Information Technology) - Pro E-Learning",
                    templateUrl: "views/itil-v3-foundation.html",
                    controller: ""
                })
                    .when("/web-development",
                          {
                    title: "Web Development - Pro E-Learning",
                    templateUrl: "views/web-development.html",
                    controller: ""
                })
                    .when("/web-development/ui-development",
                          {
                    title: "UI Development (Web Development) - Pro E-Learning",
                    templateUrl: "views/ui-development.html",
                    controller: "uiController"
                })
                    .when("/web-development/angular4",
                          {
                    title: "Angular 4 (Web Development) - Pro E-Learning",
                    templateUrl: "views/angular4.html",
                    controller: ""
                })
                    .when("/web-development/php",
                          {
                    title: "PHP (Web Development) - Pro E-Learning",
                    templateUrl: "views/php.html",
                    controller: ""
                })
                    .when("/rpa",
                          {
                    title: "Robotic Process Automation - Pro E-Learning",
                    templateUrl: "views/rpa.html",
                    controller: ""
                })
                    .when("/rpa/blueprism",
                          {
                    title: "Blue Prism Training (RPA) - Pro E-Learning",
                    templateUrl: "views/blueprism.html",
                    controller: "blueprismController"
                })
                    .when("/cloud-technologies",
                          {
                    title: "Cloud Technologies - Pro E-Learning",
                    templateUrl: "views/cloud-technologies.html",
                    controller: ""
                })
                    .when("/cloud-technologies/salesforce-developer",
                          {
                    title: "Salesforce Developer (Cloud Technologies) - Pro E-Learning",
                    templateUrl: "views/salesforce-developer.html",
                    controller: ""
                })
                    .when("/cloud-technologies/salesforce-administrator",
                          {
                    title: "Salesforce Administrator (Cloud Technologies) - Pro E-Learning",
                    templateUrl: "views/salesforce-administrator.html",
                    controller: ""
                })
                    .when("/cloud-technologies/azure",
                          {
                    title: "Azure (Cloud Technologies) - Pro E-Learning",
                    templateUrl: "views/azure.html",
                    controller: ""
                })
                    .when("/cloud-technologies/aws",
                          {
                    title: "AWS - Amazon Web Services (Cloud Technologies) - Pro E-Learning",
                    templateUrl: "views/aws.html",
                    controller: ""
                })
                    .when("/cloud-technologies/cloudera",
                          {
                    title: "Cloudera (Cloud Technologies) - Pro E-Learning",
                    templateUrl: "views/cloudera.html",
                    controller: ""
                })
                    .when("/cloud-technologies/servicenow",
                          {
                    title: "ServiceNow (Cloud Technologies) - Pro E-Learning",
                    templateUrl: "views/servicenow.html",
                    controller: ""
                })
                    .when("/cloud-technologies/openstack",
                          {
                    title: "OpenStack (Cloud Technologies) - Pro E-Learning",
                    templateUrl: "views/openstack.html",
                    controller: ""
                })
                    .when("/mobile-apps",
                          {
                    title: "Mobile Applications - Pro E-Learning",
                    templateUrl: "views/mobile-applications.html",
                    controller: ""
                })
                    .when("/mobile-apps/android",
                          {
                    title: "Android (Mobile Applications) - Pro E-Learning",
                    templateUrl: "views/android.html",
                    controller: ""
                })
                    .when("/mobile-apps/ios",
                          {
                    title: "iOS (Mobile Applications) - Pro E-Learning",
                    templateUrl: "views/ios.html",
                    controller: ""
                })
                    .when("/network-security",
                          {
                    title: "Network & Security - Pro E-Learning",
                    templateUrl: "views/network-security.html",
                    controller: ""
                })
                    .when("/network-security/ccna",
                          {
                    title: "CCNA (Network & Security) - Pro E-Learning",
                    templateUrl: "views/ccna.html",
                    controller: ""
                })
                    .when("/network-security/cyber-network-security",
                          {
                    title: "Cyber Network Security (Network & Security) - Pro E-Learning",
                    templateUrl: "views/cyber-network-security.html",
                    controller: ""
                })
                    .when("/application-support",
                          {
                    title: "Application Support - Pro E-Learning",
                    templateUrl: "views/application-support.html",
                    controller: ""
                })
                    .when("/application-support/devops",
                          {
                    title: "DevOps (Application Support) - Pro E-Learning",
                    templateUrl: "views/devops.html",
                    controller: ""
                })
                    .when("/data-management",
                          {
                    title: "Data Management - Pro E-Learning",
                    templateUrl: "views/data-management.html",
                    controller: ""
                })
                    .when("/data-management/hadoop",
                          {
                    title: "Hadoop (Data Management) - Pro E-Learning",
                    templateUrl: "views/hadoop.html",
                    controller: ""
                })
                    .when("/data-management/hadoop-administrator",
                          {
                    title: "Hadoop Admin (Data Management) - Pro E-Learning",
                    templateUrl: "views/hadoop-administrator.html",
                    controller: ""
                })
                    .when("/data-management/hp-vertica",
                          {
                    title: "HP Vertica (Data Management) - Pro E-Learning",
                    templateUrl: "views/hp-vertica.html",
                    controller: ""
                })
                    .when("/data-management/talend",
                          {
                    title: "Talend (Data Management) - Pro E-Learning",
                    templateUrl: "views/talend.html",
                    controller: ""
                })
                    .when("/business-intelligence",
                          {
                    title: "Business Intelligence - Pro E-Learning",
                    templateUrl: "views/business-intelligence.html",
                    controller: ""
                })
                    .when("/business-intelligence/msbi",
                          {
                    title: "MSBI (Business Intelligence) - Pro E-Learning",
                    templateUrl: "views/msbi.html",
                    controller: ""
                })
                    .when("/business-intelligence/obiee",
                          {
                    title: "OBIEE (Business Intelligence) - Pro E-Learning",
                    templateUrl: "views/obiee.html",
                    controller: ""
                })
                    .when("/business-intelligence/power-bi",
                          {
                    title: "Power BI (Business Intelligence) - Pro E-Learning",
                    templateUrl: "views/power-bi.html",
                    controller: ""
                })
                    .when("/erp",
                          {
                    title: "ERP - Pro E-Learning",
                    templateUrl: "views/erp.html",
                    controller: ""
                })
                    .when("/erp/people-soft-hrms",
                          {
                    title: "People Soft HRMS (ERP) - Pro E-Learning",
                    templateUrl: "views/people-soft-hrms.html",
                    controller: ""
                })
                    .when("/erp/salesforce-crm",
                          {
                    title: "Salesforce CRM (ERP) - Pro E-Learning",
                    templateUrl: "views/salesforce-crm.html",
                    controller: ""
                })
                    .when("/erp/oracle-apps",
                          {
                    title: "Oracle Apps (ERP) - Pro E-Learning",
                    templateUrl: "views/oracle-apps.html",
                    controller: ""
                })
                    .when("/erp/sap-bi",
                          {
                    title: "SAP BI (ERP) - Pro E-Learning",
                    templateUrl: "views/sap-bi.html",
                    controller: ""
                })
                    .when("/erp/sap-bo",
                          {
                    title: "SAP BO (ERP) - Pro E-Learning",
                    templateUrl: "views/sap-bo.html",
                    controller: ""
                })
                    .when("/erp/sap-crm",
                          {
                    title: "SAP CRM (ERP) - Pro E-Learning",
                    templateUrl: "views/sap-crm.html",
                    controller: ""
                })
                    .when("/erp/sap-fico",
                          {
                    title: "SAP FICO (ERP) - Pro E-Learning",
                    templateUrl: "views/sap-fico.html",
                    controller: ""
                })
                    .when("/erp/sap-hana",
                          {
                    title: "SAP HANA (ERP) - Pro E-Learning",
                    templateUrl: "views/sap-hana.html",
                    controller: ""
                })
                    .when("/erp/sap-mm",
                          {
                    title: "SAP MM (ERP) - Pro E-Learning",
                    templateUrl: "views/sap-mm.html",
                    controller: ""
                })
                    .when("/erp/sas",
                          {
                    title: "SAS (ERP) - Pro E-Learning",
                    templateUrl: "views/sas.html",
                    controller: ""
                })
                    .when("/erp/sas-clinical-research",
                          {
                    title: "SAS Clinical Research (ERP) - Pro E-Learning",
                    templateUrl: "views/sas-clinical-research.html",
                    controller: ""
                })
                    .when("/erp/sas-bi",
                          {
                    title: "SAS BI (ERP) - Pro E-Learning",
                    templateUrl: "views/sas-bi.html",
                    controller: ""
                })
                    .when("/etl",
                          {
                    title: "ETL - Pro E-Learning",
                    templateUrl: "views/etl.html",
                    controller: ""
                })
                    .when("/etl/datastage",
                          {
                    title: "DataStage (ETL) - Pro E-Learning",
                    templateUrl: "views/datastage.html",
                    controller: ""
                })
                    .when("/etl/informatica",
                          {
                    title: "Informatica (ETL) - Pro E-Learning",
                    templateUrl: "views/informatica.html",
                    controller: ""
                })
                    .when("/etl/informatica-mdm",
                          {
                    title: "Informatica MDM (ETL) - Pro E-Learning",
                    templateUrl: "views/informatica-mdm.html",
                    controller: ""
                })
                    .when("/business-management",
                          {
                    title: "Business Management - Pro E-Learning",
                    templateUrl: "views/business-mgmt.html",
                    controller: ""
                })
                    .when("/business-management/jbpm",
                          {
                    title: "jBPM (Business Management) - Pro E-Learning",
                    templateUrl: "views/jbpm.html",
                    controller: ""
                })
                    .when("/business-management/pega-6.2",
                          {
                    title: "Pega 6.2 (Business Management) - Pro E-Learning",
                    templateUrl: "views/pega-6.2.html",
                    controller: ""
                })
                    .when("/business-management/pega-7",
                          {
                    title: "Pega 7 (Business Management) - Pro E-Learning",
                    templateUrl: "views/pega-7.html",
                    controller: ""
                })
                    .when("/business-management/business-analyst",
                          {
                    title: "Business Analyst (Business Management) - Pro E-Learning",
                    templateUrl: "views/business-analyst.html",
                    controller: ""
                })
                    .when("/business-management/ba-bfsi",
                          {
                    title: "BA - BFSI (Business Management) - Pro E-Learning",
                    templateUrl: "views/ba-bfsi.html",
                    controller: ""
                })
                    .when("/business-management/ba-health-care",
                          {
                    title: "BA - Health Care (Business Management) - Pro E-Learning",
                    templateUrl: "views/ba-health-care.html",
                    controller: ""
                })
                    .when("/business-management/ba-finance",
                          {
                    title: "BA - Finance (Business Management) - Pro E-Learning",
                    templateUrl: "views/ba-finance.html",
                    controller: ""
                })
                    .when("/business-management/quickbooks",
                          {
                    title: "QuickBooks (Business Management) - Pro E-Learning",
                    templateUrl: "views/quickbooks.html",
                    controller: ""
                })
                    .when("/business-management/technical-manager",
                          {
                    title: "Technical Manager (Business Management) - Pro E-Learning",
                    templateUrl: "views/technical-manager.html",
                    controller: ""
                })
                    .when("/analytical-tools",
                          {
                    title: "ETL - Pro E-Learning",
                    templateUrl: "views/analytical-tools.html",
                    controller: ""
                })
                    .when("/analytical-tools/tableau",
                          {
                    title: "Tableau (Analytical Tools) - Pro E-Learning",
                    templateUrl: "views/tableau.html",
                    controller: ""
                })
                    .when("/analytical-tools/remedy-ticketing-tool",
                          {
                    title: "Remedy Ticketing Tool (Analytical Tools) - Pro E-Learning",
                    templateUrl: "views/remedy-ticketing-tool.html",
                    controller: ""
                })
                    .when("/analytical-tools/qlikview",
                          {
                    title: "QlikView (Analytical Tools) - Pro E-Learning",
                    templateUrl: "views/qlikview.html",
                    controller: ""
                })
                    .when("/analytical-tools/tibco-spotfire",
                          {
                    title: "Tibco Spotfire (Analytical Tools) - Pro E-Learning",
                    templateUrl: "views/tibco-spotfire.html",
                    controller: ""
                })
                    .when("/software-testing",
                          {
                    title: "Software Testing - Pro E-Learning",
                    templateUrl: "views/software-testing.html",
                    controller: ""
                })
                    .when("/software-testing/perfecto",
                          {
                    title: "Perfecto (Software Testing) - Pro E-Learning",
                    templateUrl: "views/perfecto.html",
                    controller: ""
                })
                    .when("/software-testing/loadrunner",
                          {
                    title: "HP LoadRunner (Software Testing) - Pro E-Learning",
                    templateUrl: "views/loadrunner.html",
                    controller: ""
                })
                    .when("/software-testing/selenium",
                          {
                    title: "Selenium (Software Testing) - Pro E-Learning",
                    templateUrl: "views/selenium.html",
                    controller: ""
                })
                    .when("/software-testing/etl-testing",
                          {
                    title: "ETL Testing (Software Testing) - Pro E-Learning",
                    templateUrl: "views/etl-testing.html",
                    controller: ""
                })
                    .when("/software-testing/web-app-penetration-testing",
                          {
                    title: "Web Application Penetration Testing (Software Testing) - Pro E-Learning",
                    templateUrl: "views/web-app-pen-testing.html",
                    controller: ""
                })
                    .when("/hyperion",
                          {
                    title: "Hyperion - Pro E-Learning",
                    templateUrl: "views/hyperion.html",
                    controller: ""
                })
                    .when("/hyperion/hpcm",
                          {
                    title: "HPCM (Hyperion) - Pro E-Learning",
                    templateUrl: "views/hpcm.html",
                    controller: ""
                })
                    .when("/hyperion/hyperion-epm",
                          {
                    title: "Hyperion EPM (Hyperion) - Pro E-Learning",
                    templateUrl: "views/hyperion-epm.html",
                    controller: ""
                })
                    .when("/hyperion/hyperion-essbase",
                          {
                    title: "Hyperion Essbase (Hyperion) - Pro E-Learning",
                    templateUrl: "views/hyperion-essbase.html",
                    controller: ""
                })
                    .when("/hyperion/hyperion-financial-management",
                          {
                    title: "Hyperion Financial Management (Hyperion) - Pro E-Learning",
                    templateUrl: "views/hyperion-financial-management.html",
                    controller: ""
                })
                    .when("/ibm",
                          {
                    title: "IBM - Pro E-Learning",
                    templateUrl: "views/ibm.html",
                    controller: ""
                })
                    .when("/ibm/webfocus",
                          {
                    title: "WebFocus (IBM) - Pro E-Learning",
                    templateUrl: "views/webfocus.html",
                    controller: ""
                })
                    .when("/ibm/websphere-admin",
                          {
                    title: "WebSphere Admin (IBM) - Pro E-Learning",
                    templateUrl: "views/websphere-admin.html",
                    controller: ""
                })
                    .when("/ibm/websphere-message-broker",
                          {
                    title: "WebSphere Message Broker (IBM) - Pro E-Learning",
                    templateUrl: "views/wmb.html",
                    controller: ""
                })
                    .when("/oracle",
                          {
                    title: "Oracle - Pro E-Learning",
                    templateUrl: "views/oracle.html",
                    controller: ""
                })
                    .when("/oracle/oracle-adf",
                          {
                    title: "Oracle ADF (Oracle) - Pro E-Learning",
                    templateUrl: "views/oracle-adf.html",
                    controller: ""
                })
                    .when("/oracle/oracle-dba",
                          {
                    title: "Oracle DBA (Oracle) - Pro E-Learning",
                    templateUrl: "views/oracle-dba.html",
                    controller: ""
                })
                    .when("/oracle/oracle-developer",
                          {
                    title: "Oracle Developer (Oracle) - Pro E-Learning",
                    templateUrl: "views/oracle-developer.html",
                    controller: ""
                })
                    .when("/oracle/oracle-ebs",
                          {
                    title: "Oracle EBS (Oracle) - Pro E-Learning",
                    templateUrl: "views/oracle-ebs.html",
                    controller: ""
                })
                    .when("/oracle/oracle-golden-gate",
                          {
                    title: "Oracle Golden Gate (Oracle) - Pro E-Learning",
                    templateUrl: "views/oracle-golden-gate.html",
                    controller: ""
                })
                    .when("/oracle/oracle-soa",
                          {
                    title: "Oracle SOA (Oracle) - Pro E-Learning",
                    templateUrl: "views/oracle-soa.html",
                    controller: ""
                })
                    .when("/oracle/weblogic",
                          {
                    title: "WebLogic (Oracle) - Pro E-Learning",
                    templateUrl: "views/weblogic.html",
                    controller: ""
                })
                    .when("/oracle/siebel-open-ui",
                          {
                    title: "Siebel Open UI (Oracle) - Pro E-Learning",
                    templateUrl: "views/siebel-open-ui.html",
                    controller: ""
                })
                    .when("/oracle/odi-12c",
                          {
                    title: "ODI 12C (Oracle) - Pro E-Learning",
                    templateUrl: "views/odi-12c.html",
                    controller: ""
                })
                    .when("/registration",
                          {
                    title: "Registration - Pro E-Learning",
                    templateUrl: "views/registration.html",
                    controller: ""
                })
                    .when("/trainer_login",
                          {
                    title: "Trainer Login - Pro E-Learning",
                    templateUrl: "views/trainer_login.html",
                    controller: "trainerLoginController"
                })
                    .when("/contact",
                          {
                    title: "Contact Us - Pro E-Learning",
                    templateUrl: "views/contact.html",
                    controller: "contactController"
                })
                    .when("/sitemap",
                          {
                    title: "Sitemap - Pro E-Learning",
                    templateUrl: "views/sitemap.html",
                    controller: ""
                })
                    /* Default Path To Load */
                    .otherwise(
                        {
                    title: "404 Page Not Found - Pro E-Learning",
                    redirectTo: "/404",
                    templateUrl: "views/404.html"
                })
                
                /* Configure HTML5 To Get Links Working */
                $locationProvider.html5Mode(true).hashPrefix('!');
                
                
}])

;